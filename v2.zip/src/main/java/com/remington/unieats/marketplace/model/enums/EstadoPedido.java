package com.remington.unieats.marketplace.model.enums;

public enum EstadoPedido {
    PENDIENTE,
    EN_PREPARACION,
    LISTO_PARA_RECOGER,
    COMPLETADO,
    CANCELADO
}