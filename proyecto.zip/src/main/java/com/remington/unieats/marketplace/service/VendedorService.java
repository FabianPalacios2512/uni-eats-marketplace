package com.remington.unieats.marketplace.service;

import com.remington.unieats.marketplace.dto.HorarioUpdateDTO;
import com.remington.unieats.marketplace.dto.TiendaCreacionDTO;
import com.remington.unieats.marketplace.dto.TiendaUpdateDTO;
import com.remington.unieats.marketplace.model.entity.Horario;
import com.remington.unieats.marketplace.model.entity.Tienda;
import com.remington.unieats.marketplace.model.entity.Usuario;
import org.springframework.web.multipart.MultipartFile;
import java.util.List;
import java.util.Optional;

public interface VendedorService {
    Optional<Tienda> findTiendaByVendedor(Usuario vendedor);
    Tienda crearTienda(TiendaCreacionDTO tiendaDTO, Usuario vendedor, MultipartFile logoFile);
    Tienda actualizarTienda(Tienda tienda, TiendaUpdateDTO updateDTO, MultipartFile logoFile);
    List<Horario> findHorariosByTienda(Tienda tienda);
    void actualizarHorarios(Tienda tienda, List<HorarioUpdateDTO> horariosDTO);
}